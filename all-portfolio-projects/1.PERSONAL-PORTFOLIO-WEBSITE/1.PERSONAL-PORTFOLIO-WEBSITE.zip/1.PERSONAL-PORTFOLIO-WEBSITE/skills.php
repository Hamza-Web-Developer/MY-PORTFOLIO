<!DOCTYPE html>
<html lang="en">
<head>
        <!-- TITLE AND FAVICONS CODE STARTS -->
        <?php include 'components/title and favicon.php'; ?>
        <!-- TITLE AND FAVICONS CODE ENDS -->
</head>
<body class="bg-stone-950">

<!-- NAVBAR CODE STARTS -->

<?php include 'components/navbar.php'; ?>

<!-- NAVBAR CODE ENDS -->

<!-- MY SKILLS CODE STARTS -->

<?php include 'components/my skills.php'; ?>

<!-- MY SKILLS CODE ENDS -->

<!-- ABOUT ME CODE STARTS -->

<?php include 'components/about.php'; ?>

<!-- ABOUT ME CODE ENDS -->

<!-- PROJECTS CODE STARTS -->

<?php include 'components/projects.php'; ?>

<!-- PROJECTS CODE ENDS -->

<!-- KEEP IN TOUCH CODE STARTS -->

<?php include 'components/keep in touch.php'; ?>

<!-- KEEP IN TOUCH CODE ENDS -->

</body>
</html>