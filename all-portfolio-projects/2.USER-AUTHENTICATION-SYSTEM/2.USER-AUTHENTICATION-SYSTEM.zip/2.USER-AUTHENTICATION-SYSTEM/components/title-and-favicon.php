<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://unpkg.com/@tailwindcss/browser@4"></script>
<link rel="icon" type="image/x-icon" href="img/LOGO.png">
<link rel="stylesheet" href="css/style.css">
<title>USER-AUTHENTICATION-SYSTEM</title>