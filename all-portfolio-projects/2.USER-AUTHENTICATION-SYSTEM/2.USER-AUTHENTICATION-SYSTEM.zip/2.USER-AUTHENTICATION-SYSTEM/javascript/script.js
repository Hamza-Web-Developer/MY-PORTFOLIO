document.getElementById('close-toast').addEventListener('click', function () {
        document.getElementById('toast-default').style.display = 'none';
});

// SIDEBAR SCRIPT CODE STARTS

const sidebar = document.getElementById("default-sidebar");
const toggleButton = document.getElementById("sidebarToggle");

toggleButton.addEventListener("click", () => {
    sidebar.classList.toggle("-translate-x-full");
});

// SIDEBAR SCRIPT CODE ENDS