<?php
$host = "localhost";
$user = "root"; // Change as per your DB credentials
$pass = "";
$dbname = "url_shortener";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>