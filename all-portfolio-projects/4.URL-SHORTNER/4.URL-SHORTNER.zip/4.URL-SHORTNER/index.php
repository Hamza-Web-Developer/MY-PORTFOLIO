<!DOCTYPE html>
<html lang="en">
<head>
    <?php include 'components/title-and-favicon.php'; ?>
</head>
<body>

<!-- URL SHORTNER CODE STARTS -->

<section class="bg-gray-50 dark:bg-gray-900 min-h-screen flex items-center justify-center" style="background-image: url('img/bg-2.jpg'); background-size: cover; background-position: center;">
  <div class="w-full max-w-md bg-white rounded-lg shadow-md dark:bg-gray-800 dark:border dark:border-gray-700">
      <div class="p-6 sm:p-8">
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white text-center">
              ENTER YOUR URL
          </h1>
          <form class="mt-6 space-y-4" action="shorten.php" method="POST">
              <div>
                  <input type="url" name="long_url" required class="w-full p-2.5 mt-1 border rounded-lg text-gray-900 bg-gray-50 border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                         placeholder="YOUR URL">
              </div>
              <button type="submit" class="w-full bg-blue-600 text-white font-medium py-2.5 rounded-lg text-center hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                  SHORT YOUR URL
              </button>
          </form>
      </div>
  </div>
</section>

<!-- URL SHORTNER CODE ENDS -->