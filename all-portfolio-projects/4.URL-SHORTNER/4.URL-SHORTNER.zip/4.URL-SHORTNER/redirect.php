<?php
include 'config.php';

if (isset($_GET['c'])) {
    $short_code = $_GET['c'];
    
    $stmt = $conn->prepare("SELECT long_url FROM urls WHERE short_code = ?");
    $stmt->bind_param("s", $short_code);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($long_url);
        $stmt->fetch();
        header("Location: " . $long_url);
        exit();
    } else {
        echo "URL not found!";
    }
    
    $stmt->close();
}

$conn->close();
?>